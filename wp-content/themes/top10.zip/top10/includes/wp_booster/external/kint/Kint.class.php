<?php
if ( !class_exists( 'Kint' ) ) {
	require __DIR__ . '/_main.php';
}