<div id="td-header-menu">
    <div id="td-top-mobile-toggle"><a href="#"><i class="td-icon-font td-icon-mobile"></i></a></div>
    <div class="td-main-menu-logo">
        <?php
            locate_template('parts/logo.php', true, false);
        ?>
    </div>
</div>

<!-- Search -->
<div class="td-search-icon">
    <a id="td-header-search-button" href="#" role="button" class="dropdown-toggle " data-toggle="dropdown"><i class="td-icon-search"></i></a>
</div>